import matplotlib.pyplot as plt
x = list(range(1,101))
y = [v ** 3 for v in x]

#去除轮廓
# c = (a,b,c)或颜色字符串来指定颜色
# 颜色映射 c设置为值列表

plt.scatter(x,y,edgecolor = 'none',c = x,cmap = plt.cm.Blues,s = 50)

#加上标题及坐标标签
plt.title('Cube',fontsize = 24)
plt.xlabel('Value',fontsize = 15)
plt.ylabel('Cube of Value',fontsize = 15)
#设定坐标的取值范围
plt.axis ([0,110,0,110 **3])

plt.show()