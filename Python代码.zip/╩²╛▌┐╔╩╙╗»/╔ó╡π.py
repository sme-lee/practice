import matplotlib.pyplot as plt
plt.scatter(2,4,s = 200)
#设置图表标题并加上标签
plt.title('Squares Numebers',fontsize = 24)
plt.xlabel('Value',fontsize = 14)
plt.ylabel('Squares of Value',fontsize = 14)
#设置标记刻度的大小
plt.tick_params(axis = 'both',which = 'major',labelsize = 14)

plt.show()
