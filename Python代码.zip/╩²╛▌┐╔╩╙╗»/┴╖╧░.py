import matplotlib.pyplot as plt
x = list(range(1,101))
y = [v ** 3 for v in x]

plt.plot(x,y,linewidth = 5,color = 'Yellow')
plt.title('Cube',fontsize = 16)
plt.xlabel('Value',fontsize = 16)
plt.ylabel('Cube of value',fontsize = 16)

plt.tick_params(axis = 'both',labelsize = 16)
plt.show()