import matplotlib.pyplot as plt
input_values = list(range(1,6))

squares = [v ** 2 for v in list(range(1,6))]

# plt.plot(list)
plt.plot(input_values,squares,linewidth = 5)

#设置图表标题，并给坐标轴加上标签
plt.title('Squares Numbers',fontsize = 24)
plt.xlabel('Value',fontsize = 16)
plt.ylabel('Square of Value',fontsize = 16)
#设置标记刻度的大小
plt.tick_params(axis = 'both',labelsize = 14)

plt.show()