# 1、获取关注列表
from selenium import webdriver
import requests
import lxml.html

# 初始化webdriver
url = 'https://www.bilibili.com/'
driver = webdriver.Chrome('./chromedriver.exe')
driver.get(url)


# 1、获取分区列表
import lxml.html
import re
source = driver.page_source
selector = lxml.html.fromstring(source)
area_list = []
for i in range(1,16):
    area = selector.xpath(f'//*[@id="primaryChannelMenu"]/span[{i}]/div/a/span/text()')[0]
    area_list.append(area)

# 输出信息
print(f'共有{len(area_list)}个分区，分别为')
print(area_list)
print(f"音乐区在第{area_list.index('音乐')+1}位。")

# selenium中仍存在ajax异步加载，需要用水瓶