# 登录过程
import requests
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

# 初始化webdriver
url = 'https://passport.bilibili.com/login'
driver = webdriver.Chrome('./chromedriver.exe')
driver.get(url)

# 输入需要的信息
user = '15611531766'
pw = 'litian221719'
element = driver.find_element_by_id('login-username')
element.clear()
element.send_keys(user)

password = driver.find_element_by_id('login-passwd')
password.clear()
password.send_keys(pw)

element.send_keys(Keys.RETURN)
input('请完成验证码：')
element.send_keys(Keys.RETURN)
print(driver.page_source)




