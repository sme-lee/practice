#获取贴吧前20页的标题
import requests
import re
from multiprocessing.dummy import Pool
#定义获取一个页面标题的函数
def get_titles(url):
    source = requests.get(url).content.decode()
    titles = re.findall(' target="_blank" class="j_th_tit ">(.*?)</a>',source,re.S)
    return titles


#获取前20页标题的网址列表
start_url = 'https://tieba.baidu.com/f?kw=%E9%B9%BF%E4%B9%83&ie=utf-8&pn='
urls = [start_url + str(i) for i in list(range(0,50*20,50))]
title_last = []     #用列表的列表方式用下标来代替页数和标题的序列
lost  = []      #表示缺失标题的页数
for i in range(len(urls)):
    print(f'第{i+1}页的标题有：')
    titles = get_titles(urls[i])
    title_last.append(titles)
    for title in titles:
        print(title)
    print(f'共有{len(titles)}个标题。')

    if i != 0 and len(titles)!= 50:
        lost.append(i+1)
    print(' ')
for i in lost:
    print(f"第{i}页标题有缺失。")
print('\n\n')

print(f'符合要求的标题为：\n')
for i in range(len(title_last)):
    #   i表示页数-1
    for j in range(len(title_last[i])):
        #   j表示一页中的标题数-1

        if '照' in title_last[i][j]:
            print(f'{title_last[i][j]}，是第{i+1}页的第{j+1}个标题。\n')
