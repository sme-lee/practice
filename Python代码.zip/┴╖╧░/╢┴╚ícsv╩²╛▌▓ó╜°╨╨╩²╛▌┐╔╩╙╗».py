# 读取csv文件
import csv
name_list = []
age_list = []
salary_list = []
with open('new.csv',encoding = 'utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row)
        name_list.append(row['name'])
        age_list.append(row['age'])
        salary_list.append(row['salary'])
name_list = list(set(name_list))
age_list = list(set(age_list))
salary_list = list(set(salary_list))

# 数据可视化
import matplotlib.pyplot as plt

plt.plot(name_list,age_list,c = 'orange',linewidth = 0.5)

# 标题及坐标轴
plt.title('exercise',fontsize = 20)
plt.xlabel('name',fontsize = 16)
plt.ylabel('age',fontsize = 16)
plt.tick_params(axis = 'both',labelsize = 14)

plt.show()
