from selenium import webdriver
import lxml.html

# 初始化driver
url = 'https://space.bilibili.com/316381099/fans/follow'
driver = webdriver.Chrome('./chromedriver.exe')
driver.get(url)

# 爬取信息
source = driver.page_source
name_list = []
intr_list = []
selector = lxml.html.fromstring(source)
for i in range(1,21):
    name_list.append(selector.xpath(f'//*[@id="page-follows"]/div/div[2]/div[2]/div[2]/ul[1]/li[{i}]/div['
                                    f'2]/a/span/text()')[0])
    intr_list.append(selector.xpath(f'//*[@id="page-follows"]/div/div[2]/div[2]/div[2]/ul[1]/li[{i}]/div['
                                    f'2]/p/text()')[0].lstrip())
for i in range(len(name_list)):
    print(f'关注的人：{name_list[i]}\n简介：{intr_list[i]}')