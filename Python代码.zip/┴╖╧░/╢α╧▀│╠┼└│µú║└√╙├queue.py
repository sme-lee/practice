import threading
import time
import queue as Queue
import requests

url = 'https://www.baidu.com/'
def get_source(url):
    content = requests.get(url).content.decode()

# 单线程
start = time.time()
count = 0
while count < 10:
    count += 1
    get_source(url)
end = time.time()
time_1 = end -start

# 多线程
class myThread(threading.Thread):
    def __init__(self,name , q):
        threading.Thread.__init__(self)
        self.name = name
        self.q = q
    def run(self):
        print(self.name ,'开始')
        while not self.q.empty():
            num = self.q.get()
            get_source(url)
        print(self.name ,'结束')

# 创建队列
workqueue = Queue.Queue(10)
for i in range(10):
    workqueue.put(i)

# 创建线程
num = int(input('请输入线程数'))
start = time.time()

t_s = [f'线程{i}'for i in range(1,num+1)]
ts = []
for t in t_s :
    thread = myThread(t,workqueue)
    thread.start()
    ts.append(thread)
for t in ts:
    t.join()
end = time.time()
time_2 = end-start
print(f'花费的时间分别为：{time_1,time_2}\n两者相差{time_1/time_2}倍')

