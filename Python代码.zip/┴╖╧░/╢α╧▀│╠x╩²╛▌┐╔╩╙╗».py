#多线程计算一万次
import time

from multiprocessing.dummy import Pool
def cd (x):
    #   x为一个数
    y = x ** 2
    return y
def multi(n,x):
    #   n代表线程，
    #   返回值为花费的时间
    start = time.time()
    pool = Pool(n)
    results = pool.map(cd,x)
    end = time.time()
    print(f'{n}线程花费的时间为{end-start}秒。')
    return end-start
x = list(range(1,10**6+1))
n_list = list(range(1,101))
time_list = []
for n in n_list:
    #对于每个线程
    time_list.append(multi(n,x))
if max(time_list) - min(time_list) < 1 :
    print(f'多线程计算数据对时间的影响不大。')
print(f'花费时间最短的线程是{time_list.index(min(time_list))+1}线程，花费的时间为{min(time_list)}秒。',
      f'花费时间最短的线程是{time_list.index(max(time_list))+1}线程，花费的时间为{max(time_list)}秒。',
      f'最大时间差距为{max(time_list)-min(time_list)}秒。')

#数据可视化
import matplotlib.pyplot as plt
x = [ index for index in list(range(len(time_list)))]
plt.plot(x,time_list,linewidth = 1,color = 'orange')
    #加入标题，x，y轴
plt.title('time-needed',fontsize = 16)
plt.xlabel('multi',fontsize = 16)
plt.ylabel('time',fontsize = 16)
plt.tick_params(axis = 'both',labelsize = 16)
plt.show()

