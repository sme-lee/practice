import csv
# 写入文件
data = [{'name':'kingname','age':24,'salary':99999},
        {'name':'meiji','age':20,'salary':100},
        {'name':'小明','age':30,'salary':'N/A'}]
with open('new.csv','w',encoding= 'utf-8') as f:
    writer = csv.DictWriter(f,fieldnames = ['name','age','salary'])
    writer.writeheader()
    writer.writerows(data)
    writer.writerow({'name':'超人','age':999,'salary':0})

# 读取文件
name_list = []
age_list = []
salary_list = []
with open('new.csv',encoding = 'utf-8') as f:
    reader = csv.DictReader(f)
    print(reader)
    for row in reader:
        print(row)

# txt和csv通用操作
# f.read()返回字符串，f.readline()返回第一行，f.readlines()返回列表（回车键也存入列表）
# f.write(str)，f.writelines(list)写入数据