#   求list中最大元素的索引
x = list(range(101))
print(x.index(max(x)))
print(max(x))

x = [1,1,1,1]
print(max(x))
print(x.index(max(x)))
