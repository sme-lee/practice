# 获取的信息大致为：观看人数，点赞数，投币数，收藏数，评论数
# 用 selenium 浏览器获取异步加载的信息
# 用 xpath 和正则表达式获取信息

import requests
import lxml.html
import re
from selenium import webdriver

url = 'https://www.bilibili.com/video/BV12k4y127mJ'

driver = webdriver.Chrome('./chromedriver.exe')

def get_info(url):
    info = {}
    driver.get(url)
    source = driver.page_source
    selector = lxml.html.fromstring(source)

    # 获取相关信息并完成字典
    # people = selector.xpath('//*[@id="bilibiliPlayer"]/div[1]/div[2]/div/div[1]/div[1]/span[1]')
    people = selector.xpath('//*[@id="bilibiliPlayer"]/div[1]/div[2]/div/div[1]/div[1]/span[1]/text()')
    info['观看人数'] = people

    like_on = re.findall('点赞数(.*?)"', source, re.S)[0]
    info['点赞数'] = like_on

    collect_on = re.findall('收藏人数(.*?)"', source, re.S)[0]
    info['收藏数'] = collect_on

    comment = selector.xpath('//*[@id="comment"]/div/div[1]/span[1]/text()')
    info['评论数'] = comment

    driver.quit()

    return info

print(get_info(url))





