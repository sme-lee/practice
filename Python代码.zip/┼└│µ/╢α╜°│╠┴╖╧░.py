from multiprocessing import Pool, Manager
import time
import requests

# 制作网址列表
def get_urls():
    with open('网址列表.csv') as f:
        link_list = f.readlines()
        link_list = [link.replace('\n','') for link in link_list]
    link_list = link_list + link_list
    return link_list
url_list = get_urls()


# 定义抓取函数
def get_code(name, workqueue):
    while not workqueue.empty():
        url = workqueue.get()
        try:
            code = requests.get(url).status_code
            print(name, workqueue.qsize(), code, url)
        except Exception as e:
            print(name, workqueue.qsize(), e)

if __name__ == '__main__':
    start = time.time()
    # 建立队列并填充
    manager = Manager()
    workqueue = manager.Queue(len(url_list))
    for url in url_list:
        workqueue.put(url)


    # 确立进程名列表和进程池
    pro_num = 10
    names = [f'进程{i}'for i in range(1,pro_num + 1)]

    pool = Pool(pro_num)
    for name in names:
        pool.apply_async(get_code,(name, workqueue))
    pool.close()
    pool.join()
    end = time.time()

    print(f'花费的总时间为：', end - start)