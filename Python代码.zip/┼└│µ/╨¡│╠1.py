from gevent import monkey
monkey.patch_all()
import gevent
import requests

def f(url):
    print(f'获取{url}')
    res = requests.get(url).content.decode()
    print(len(res), url)

gevent.joinall([
    gevent.spawn(f, 'https://www.python.org/'),
    gevent.spawn(f, 'https://www.yahoo.com/'),
    gevent.spawn(f, 'https://github.com/'),
])