list = [str(1), str(600)]
with open('uid上下限.csv', 'w') as f:
    for uid in list:
        f.write(uid)
        f.write('\n')