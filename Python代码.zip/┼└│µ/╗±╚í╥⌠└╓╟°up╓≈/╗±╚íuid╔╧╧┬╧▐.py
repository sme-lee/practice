with open('uid上下限.csv') as f:
    list = f.readlines()
    list = [str_i.replace('\n','') for str_i in list]
print(list)