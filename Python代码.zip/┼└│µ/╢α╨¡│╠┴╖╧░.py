
from gevent import monkey
monkey.patch_all()                  # 将 IO 转为异步执行的函数

import gevent
from gevent.queue import Queue, Empty
import time
import requests

# 制作网址列表
def get_urls():
    with open('网址列表.csv') as f:
        link_list = f.readlines()
        link_list = [link.replace('\n','') for link in link_list]
    link_list = link_list + link_list
    return link_list
url_list = get_urls()


start = time.time()
def crawler(index):
    Process_id = 'Process-' + str(index)
    while not workQueue.empty():
        url = workQueue.get(timeout = 2)
        try:
            r = requests.get(url)
            print(Process_id, workQueue.qsize(), r.status_code, url)
        except Exception as e:
            print(Process_id, workQueue.qsize(), url, 'Error:', e)

def boss():
    for url in url_list:
        workQueue.put_nowait(url)
if __name__ == '__main__':
    workQueue = Queue(len(url_list))
    gevent.spawn(boss).join()
    jobs = []
    for i in range(35):
        jobs.append(gevent.spawn(crawler, i))
    gevent.joinall(jobs)
    end = time.time()
    print('gevent + Queue多协程爬虫的总时间为', end - start)