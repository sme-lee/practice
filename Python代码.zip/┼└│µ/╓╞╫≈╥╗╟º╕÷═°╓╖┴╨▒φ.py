# 定义获取网址列表的函数
# 功能：获取大量网址（数量为1000）
# 参数：无
# 返回值：网址列表
def get_urls():
    with open('网址列表.csv') as f:
        link_list = f.readlines()
        link_list = [link.replace('\n','') for link in link_list]
    link_list = link_list + link_list
    return link_list


