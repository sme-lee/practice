import requests
import lxml.html
import re
import time

# 需要抓取网址的列表
url_list = []
url_list.append('https://alexa.chinaz.com/Country/index_CN.html')
for i in range(2, 21):
    url_list.append(f'https://alexa.chinaz.com/Country/index_CN_{i}.html')

# 存放网址的列表
link_list = []


# 定义抓取每页网站的函数
# 功能：获取网址并将其加入到一个列表中
# 参数：每页的网址
# 返回值：无
def get_urls(url):
    source = requests.get(url).content.decode()
    big = re.findall('rowlist(.*?)basePage', source, re.S)[0]
    big_2 = re.findall('</span>(.*?)</h3>', big, re.S)
    for big_2_small in big_2:
        link = re.findall('href="(.*?)"', big_2_small, re.S)[0]
        if (requests.get(link).status_code == 200):
            link_list.append(link)
# 定义存放网址的函数
# 功能：将网址写入csv文件
# 参数：网址列表
# 返回值：无
def write_link(link_list):
    with open('网址列表.csv', 'a+', encoding = 'utf-8') as f:           # 写入文件
        for link in link_list:
            f.write(link)
            f.write('\n')

for url in url_list:
    try:
        get_urls(url)
        print(f'第{url_list.index(url) + 1}页抓取完成。')
    except Exception as e:
        print(f'第{url_list.index(url) + 1}页缺失。')
write_link(link_list)

print('文件制作完成。')