import time
import threading
import requests
import queue as Queue


# 制作网址列表
def get_urls():
    with open('网址列表.csv') as f:
        link_list = f.readlines()
        link_list = [link.replace('\n','') for link in link_list]
    link_list = link_list + link_list
    return link_list
url_list = get_urls()

class my_thread(threading.Thread):
    # 初始化属性
    def __init__(self, name, q):
        threading.Thread.__init__(self)
        self.q = q
        self.name = name
    def run(self):
        while not self.q.empty():
            url = self.q.get(timeout = 2)
            try:
                code = requests.get(url).status_code
                print(self.name, self.q.qsize(), code, url)
            except Exception as e:
                print(self.name, e)
        print(f'{self.name}结束')


start = time.time()


# 建立并填充队列
workqueue = Queue.Queue(len(url_list))
for url in url_list:
    workqueue.put(url)

names = [f'线程{i}' for i in range(1,36)]
thrs = []
for name in names:
    t = my_thread(name, workqueue)
    t.start()
    thrs.append(t)
for t in thrs:
    t.join()
end = time.time()

print(f'多线程花费的时间为{end - start}。')