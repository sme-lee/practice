import requests
url = 'http://exercise.kingname.info/exercise_ajax_1.html'

source = requests.get(url).content.decode()
print(source)

url_1 = 'http://exercise.kingname.info/ajax_1_backend'

content = requests.get(url_1).content.decode()
print(content)