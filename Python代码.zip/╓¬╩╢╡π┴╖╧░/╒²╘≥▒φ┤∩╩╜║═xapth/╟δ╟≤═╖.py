import requests
import json
url = 'http://exercise.kingname.info/exercise_headers_backend'
headers = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate',
    'accept-language': 'zh-CN,zh-TW;q=0.9,zh;q=0.8,en-US;q=0.7,en;q=0.6',
    'anhao': 'kingname',
    'content-type': 'application/json; charset=utf-8',
    'cookie': '__cfduid=d53d65449844f8642480919b62491ef681595815719',
    'referer': 'http://exercise.kingname.info/exercise_headers.html',
    'user-agent': '''Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36''',
    'x-requested-with': '''XMLHttpRequest'''
}
response = requests.get(url,headers = headers).content.decode()
print(response)

content = json.loads(response)
print(content)