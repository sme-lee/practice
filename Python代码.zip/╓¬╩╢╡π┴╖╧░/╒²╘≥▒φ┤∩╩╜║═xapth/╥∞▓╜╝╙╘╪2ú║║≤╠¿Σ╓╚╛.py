import requests
import re
import lxml.html
import json
url = 'http://exercise.kingname.info/exercise_ajax_2.html'
source = requests.get(url).content.decode()

print(source)

content_json = re.findall("secret = '(.*?)'",source,re.S)[0]
print(content_json)

content = json.loads(content_json)
print(content)

