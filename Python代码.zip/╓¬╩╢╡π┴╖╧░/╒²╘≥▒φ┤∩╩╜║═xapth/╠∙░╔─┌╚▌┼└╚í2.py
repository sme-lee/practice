#获取贴吧前20页的标题
import requests
import lxml.html
#定义获取一个页面标题的函数
def get_titles(url):
    source = requests.get(url).content.decode()
    selector = lxml.html.fromstring(source)
    titles = []
    for i in range(55):
        content = selector.xpath(f'//*[@id="thread_list"]/li[{str(i)}]/div/div[2]/div[1]/div[1]/a/text()')
        if len(content):
            titles += content
    return titles

#爬取第六页
url = 'https://tieba.baidu.com/f?kw=%E9%B9%BF%E4%B9%83&ie=utf-8&pn=250'
titles = get_titles(url)
for title in titles :
    print(title)
print(f'共有{len(titles)}个标题。')

import re
def get_titles_1(url):
    source = requests.get(url).content.decode()
    titles = re.findall(' target="_blank" class="j_th_tit ">(.*?)</a>',source,re.S)
    return titles
titles = get_titles_1(url)
for title in titles :
    print(title)
print(f'共有{len(titles)}个标题。')
