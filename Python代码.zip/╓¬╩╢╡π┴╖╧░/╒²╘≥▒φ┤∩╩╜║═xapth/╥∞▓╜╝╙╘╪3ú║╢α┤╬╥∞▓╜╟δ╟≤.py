import requests
import json
import re
url = 'http://exercise.kingname.info/ajax_3_backend'
secret_json = requests.get(url).content.decode()

secret = json.loads(secret_json)
print(secret)
#获取第一个需要的secret
secret_1 = secret['code']
print(secret_1)
#获取第二个
secret = requests.get('http://exercise.kingname.info/exercise_ajax_3.html').content.decode()
secret_2 = re.findall('secret_2 = \'(.*?)\'',secret,re.S)[0]
print(secret_2)

url_1 = 'http://exercise.kingname.info/ajax_3_postbackend'
response = requests.post(url_1,json = {
    'secret1':secret_1,
    'secret2':secret_2
}).content.decode()
ajax_2_dict = json.loads(response)
print(ajax_2_dict['code'])

