import re
import requests
import os

url = 'http://www.kanunu8.com/book3/6879'
#获取网页源码，正则表达式获取内容
source = requests.get(url).content.decode('gbk')

#先抓大再抓小
big_list = re.findall('正文(.*?)</tbody>',source,re.S)

#获取章节名和章节网址
chapter_list = re.findall('html">(.*?)</a></td>',big_list[0],re.S)
chapter_html_list = []
start_url = 'http://www.kanunu8.com/book3/6879'
chapter_url_list = re.findall('<a href="(.*?)">第',big_list[0],re.S)
for url_i in chapter_url_list:
    chapter_html_list.append(start_url +'/'+ url_i)

#开始获取正文
def get_article(url):
    content = requests.get(url).content.decode('gbk')
    article = re.findall('<p>(.*?)</p>',content,re.S)[0].replace('<br />','')
    return article

#创建文件
def save(chapter,article):
    os.makedirs('动物农场',exist_ok = True)
    with open(os.path.join('动物农场',chapter+'.txt'),'w',encoding = 'gbk') as f:
        f.write(article)


for i in range(len(chapter_list)):
    save(chapter_list[i],get_article(chapter_html_list[i]))


