import lxml.html
import requests
url  = 'https://jump2.bdimg.com/p/6827606927'
source = requests.get(url).content.decode()
selector = lxml.html.fromstring(source)

user_list = []
for i in range(1,21):

    user = selector.xpath(f'//*[@id="j_p_postlist"]/div[{i}]/div[2]/ul/li[3]/a/text()')

    if len(user):
        user_list.append(user[0])
    else:
        if i < 5 :
            user_list.append('该楼层不存在.')
        else:
            break
for i in user_list:
    print(i)


