import csv
data = [{'name':'kingname','age':24,'salary':99999},
        {'name':'meiji','age':20,'salary':100},
        {'name':'小明','age':30,'salary':'N/A'}]

# 步骤：打开文件，确定类，写入标题和内容
with open ('new.csv','w')as f:
    writer = csv.DictWriter(f,fieldnames=['name','age','salary'])
    writer.writeheader()
    writer.writerows(data)
