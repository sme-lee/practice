import re
import requests

url = 'https://jump2.bdimg.com/p/6478058693'
source_0 = requests.get(url).content.decode()

user = re.findall('target="_blank">(.*?)</',source_0,re.S)
print(source_0)
print(user)

