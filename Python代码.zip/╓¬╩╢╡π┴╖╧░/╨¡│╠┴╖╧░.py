# 定义消费者函数                       # 问题：协程数
# 参数：无
# 返回值：无
def consumer():
    r = ''
    while True:
        n = yield r
        if not n:
            return
        print(f'消费者正在消费{n}')
        r = '消费结束'

# 定义生产者函数
# 参数：一个生成器
# 返回值：无
def producer(c):
    c.send(None)                        # 启动生成器
    n = 0
    while n < 10:
        n += 1
        print(f'生产者正在生产{n}')
        r = c.send(n)
        print(f'消费者的反馈：{r}')
    c.close()

c = consumer()
producer(c)
