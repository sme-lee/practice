# 同时可能需要在 headers 中加入其他的元素

from fake_useragent import UserAgent
import requests

url = 'http://www.santostang.com/'
ua = UserAgent()
headers = {'User-Agent':ua.random}
response = requests.get(url = url , headers = headers).content.decode()
print(response)