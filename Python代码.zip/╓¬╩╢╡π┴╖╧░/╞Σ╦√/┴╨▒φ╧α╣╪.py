list_1 = []
list_1.append('jay')
list_1.insert(0,'kano')
print(list_1)
