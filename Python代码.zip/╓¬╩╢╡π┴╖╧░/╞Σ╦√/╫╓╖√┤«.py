str1 = 'kano'
str2 = 'name:'
print(str2+str1)
print(3*str1)
print(list(str1))
for i in str1:
    print(i)

print(len(str1))