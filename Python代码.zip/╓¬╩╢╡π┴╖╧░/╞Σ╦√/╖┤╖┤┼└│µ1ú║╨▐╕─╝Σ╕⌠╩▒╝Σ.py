# 1、间隔为 0 - 3 秒     2、设置休息时间，如爬取五次休息10秒等
import time
import random

# 前者时 0 1 2 中的数字，后者是 0 到 1 的随机数字
sleep_time = random.randint(0,2) + random.random()

print(sleep_time)
time.sleep(sleep_time)
