# 错误：# Unable to locate element: {"method":"css selector","selector":".reply-content"} (Session info: chrome=81.0.4044.138)
# 原因：其实就是执行过快来不及找到反馈信息
# 解决方法：加一个timesleep或者implicitly_wait(10)就好了

from selenium import webdriver



url = '''http://www.santostang.com/2018/07/04/hello-world/'''
# 初始化
driver = webdriver.Chrome('./chromedriver.exe')
driver.implicitly_wait(20)
driver.get(url)
source = driver.page_source

# 用xpath获取内容    1、lxml下的xpath 2、selenium下的xpath ,两者相同

# 加入解析
driver.switch_to.frame(driver.find_element_by_css_selector("iframe[title='livere']"))
comment = driver.find_elements_by_xpath('//*[@id="list"]/div[1]/div[2]/div[1]/div[1]/p')[0]
print(comment.text)

driver.quit()