import requests

# 找到真实评论网址后进行提取
link = 'https://api-zero.livere.com/v1/comments/list?callback=jQuery11240209913381159893_1596594400751&limit' \
       '=10&repSeq=4272904&requestPath' \
       '=%2Fv1%2Fcomments%2Flist&consumerSeq=1020&livereSeq=28583&smartloginSeq=5154&code=&_=1596594400753'
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537'
                        '.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36'}
source = requests.get(link,headers = headers).content.decode()

# 从json数据中提取评论

# 获取 json 的 string
# 使用json_string[json_string.find(‘{‘:-2)]， 仅仅提取字符串中符合json格式的部分
# 使用 json.loads 可以把字符串格式的响应体数据转化为 json 数据。
# 然后，利用 json 数据的结构，我们可以提取到评论的列表comment_list。
# 最后再通过一个 for 循环，提取其中的评论文本，并输出打印。
import json



url_1 = '''https://api-zero.livere.com/v1/comments/list?callback=jQuery1124036530157118523254_1596877103395&limit=10
&offset='''.replace('\n','')

url_2 = '''&repSeq=4345238&requestPath=%2Fv1%2Fcomments%2Flist&consumerSeq=1020&livereSeq=28583&smartloginSeq=5154&code\=&_=1596877103402
'''.replace('\n','')


# 切片和json加载，一般需要观察相应的数据结构
for i in range(1,3):
    url = url_1 + str(i) + url_2
    source = requests.get(url).content.decode()
    json_string = source
    json_string = json_string[json_string.find('{'):-2]
    json_data = json.loads(json_string)
    print(f'第{i}页的内容为：')
    comment_list = json_data['results']['parents']
    for each in comment_list:
        message = each['content']
        print(message)