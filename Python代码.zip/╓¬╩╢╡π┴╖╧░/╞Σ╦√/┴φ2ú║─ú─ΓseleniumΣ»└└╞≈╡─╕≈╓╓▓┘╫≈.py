# 具体操作：clear（）清除元素内容，send_keys（）模拟按键输入，click（）点击元素，submit（）提交表单
# 下滑到页面底部
#     driver.execute_script('window.scrollTo(0,document.body.scrollHeight)')
from selenium import webdriver
import time
import re

url = '''http://www.santostang.com/2018/07/04/hello-world/'''
# 初始化driver
driver = webdriver.Chrome('./chromedriver.exe')
# 隐性等待
driver.implicitly_wait(20)
driver.get(url)
# 暂停 5 秒后执行后续程序，可让程序有时间获取到反馈信息
time.sleep(5)

# 下滑到页面底部
driver.execute_script('window.scrollTo(0,document.body.scrollHeight)')
# 转换 iframe , 再找到查看更多，点击
driver.switch_to.frame(driver.find_element_by_css_selector('iframe[title="livere"]'))
load_more = driver.find_element_by_xpath(f'//*[@id="list"]/div[12]/button[2]')
load_more.click()

# 把 iframe 又转回去
driver.switch_to.default_content()
time.sleep(2)

# 在需要解析的网址中一般不使用将数据转换出网址源码的方法，而使用 css_selector 和 tag 代替正则表达式来进行数据获取
driver.switch_to.frame(driver.find_element_by_css_selector('iframe[title="livere"]'))
comments = driver.find_elements_by_css_selector('div.reply-content')
for each in comments:
    content = each.find_element_by_tag_name('p')
    print(content.text)

