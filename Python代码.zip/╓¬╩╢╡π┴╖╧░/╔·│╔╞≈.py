# 功能：生成 n 行杨辉三角
# 参数：杨辉三角行数
# 返回值：一个生成器
def triangles1(n):
    list_tri = []
    list1 = [1]
    yield list1
    list2 = [1,1]
    yield list2
    list_tri.append(list1)
    list_tri.append(list2)


    # 当杨辉三角行数小于 n 时
    while len(list_tri) < n:
        list = []
        num = 0
        for i in range(len(list_tri[-1]) - 1):
            num += list_tri[-1][i] + list_tri[-1][i + 1]
            list.append(num)
        list.append(1)
        list.insert(0,1)
        list_tri.append(list)
        yield list_tri

n = int(input('请输入杨辉三角的行数:'))
g = triangles1(n)
while True:
    try:
        print(next(g))
    except Exception as e:
        print('生成器已结束')
        break
