import requests
import re
import lxml.html

#对于单击或者通过滑块验证的验证码，最好使用cookie登录
def get_header(head):
    return dict([line.split(': ',1)for line in head.split('\n')])
a = '''accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
accept-encoding: gzip, deflate, br
accept-language: zh-CN,zh-TW;q=0.9,zh;q=0.8,en-US;q=0.7,en;q=0.6
cache-control: max-age=0
cookie: _uuid=7D23CC0B-197E-64CC-540A-CEDE839CDA7230306infoc; buvid3=7C6277D6-F37B-42E8-9498-ACC5143D7A4E70380infoc; sid=5jf4it0f; CURRENT_FNVAL=16; rpdid=|(kmJY~|Rm0J'ulml|mkJm~; bp_t_offset_444191179=415751064732721531; CURRENT_QUALITY=64; DedeUserID=444191179; DedeUserID__ckMd5=ba58c3fbac61ccd8; SESSDATA=c9aab659%2C1611587416%2C6ad16*71; bili_jct=92c403b28363e616d7f9927d433919ea; PVID=2; finger=-53268994; bp_video_offset_444191179=417826599087152733
sec-fetch-dest: document
sec-fetch-mode: navigate
sec-fetch-site: none
sec-fetch-user: ?1
upgrade-insecure-requests: 1
user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36'''

headers = get_header(a)

source = requests.get('https://www.bilibili.com/',headers = headers).content.decode()
content = re.findall('target="_blank" class="name">(.*?)</a>',source , re.S)
print(content)
