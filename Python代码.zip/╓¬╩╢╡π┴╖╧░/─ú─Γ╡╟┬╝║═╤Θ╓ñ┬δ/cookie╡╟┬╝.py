import requests
import time

start = time.time()
url = 'https://www.zhihu.com/'
source= requests.get(url).content.decode()
print(source)
end = time.time()
print(f'花费的时间为{end-start}秒。')

start = time.time()

def get_headers(head):
    return dict([line.split(': ',1)for line in head.split('\n')])
req_headers = '''accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
accept-encoding: gzip, deflate, br
accept-language: zh-CN,zh-TW;q=0.9,zh;q=0.8,en-US;q=0.7,en;q=0.6
cache-control: max-age=0
cookie: _zap=4a0b1e5e-263c-465d-a723-d576ace24235; d_c0="AICWVuDMmBGPTnPLkGERxCdkK3DsBb8P_xE=|1595092030"; _ga=GA1.2.819012626.1595092050; r_cap_id="ZDE1MjljYzYyNjlkNGJmOGJiN2JkYjNmMzg2MmY4YWU=|1595574525|844125a7fbb184e94f6671475dd3a3f43cacda6c"; cap_id="ZTc0ZmY0MTFjOGNmNDllZGFhZWZjNGRlMmE4MmEzZTg=|1595574525|f9a04c3d5b68acaadb52d5d4a428b5f974f48973"; l_cap_id="ZTA1YTAwYTVhNWY2NGNkYTgwNTliZmU5ZDU5YzUzMDc=|1595574525|c73c13bc610b027283ffa45dbdbc1f0b70f7193a"; _gid=GA1.2.1329808399.1595941506; capsion_ticket="2|1:0|10:1595945669|14:capsion_ticket|44:MGRiMWRhMjY4ZmNkNDRjZTg2YzVkM2I2MTU4MDRmNWM=|95544a8c9f53373ae5741cfd6df0622922b01facbbfb80229a26aa6005303cff"; z_c0="2|1:0|10:1595945811|4:z_c0|92:Mi4xajk4bEVBQUFBQUFBZ0paVzRNeVlFU1lBQUFCZ0FsVk5VNEVOWUFBYUV0MGM2QW80ZEo0OUx2VVAycGtMal94ZXVB|6946379f23b357d92ee782b1037f8da529ab8ee0959779dabd8a94fe9b2a62ed"; tst=r; _xsrf=6cd7274f-dca8-4900-ae20-c69bc9a0ab92; SESSIONID=q8kWLyzPz4c6sjlQ60ewtb9sMBoSVb1pJsSnlBaKxJk; JOID=UVwdBkIcRZrBBqLPJxq4SSrqaFo9anH8mkDcuXpsdvX6ecKkejyUu5gLqc4mHtxNr9AAAsYBbZkrTvFpr3c-42s=; osd=V1wTAkoaRZTFDqTPKR6wTyrkbFI7an_4kkbct35kcPX0fcqiejKQs54Lp8ouGNxDq9gGAsgFZZ8rQPVhqXcw52M=; Hm_lvt_98beee57fd2ef70ccdd5ca52b9740c49=1595952006,1595953226,1595985962,1595987692; q_c1=823ffb5b6fb54659991ce0e9a1c9a976|1595988423000|1595988423000; Hm_lpvt_98beee57fd2ef70ccdd5ca52b9740c49=1596064490; KLBRSID=37f2e85292ebb2c2ef70f1d8e39c2b34|1596076915|1596074743
sec-fetch-dest: document
sec-fetch-mode: navigate
sec-fetch-site: none
sec-fetch-user: ?1
upgrade-insecure-requests: 1
user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36'''
headers = get_headers(req_headers)

session = requests.Session()
source_login = session.get('https://www.zhihu.com/',headers = headers,verify = False).content.decode()
print(source_login)
end = time.time()
print(f'花费的时间为{end-start}秒。')