from selenium import webdriver

driver = webdriver.Chrome(r'chromedriver.exe')

driver.get('https://www.bilibili.com/')
#获取html代码
html_0 = driver.page_source


#用xpath获取源代码中的内容
element = driver.find_elements_by_xpath('//*[@id="bili_report_douga"]/div[1]/header/div[1]/a')
ele = element[0]
print(ele.text)