from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Chrome('./chromedriver.exe')
driver.get('https://www.zhihu.com/signin?next=%2F')

#电话和密码
diag = '15611531766'
pw = 'litian221719'

elem = driver.find_element_by_name('username')   #寻找账号输入框
elem.clear()

elem.send_keys(diag)

password = driver.find_element_by_name('password')  #寻找密码输入框
password.clear()

password.send_keys(pw)
elem.send_keys(Keys.RETURN)

input('请在网页上通过验证码，完成后按任意键继续。')
elem.send_keys(Keys.RETURN) #模拟键盘回车键
time.sleep(10)

print(driver.page_source)
