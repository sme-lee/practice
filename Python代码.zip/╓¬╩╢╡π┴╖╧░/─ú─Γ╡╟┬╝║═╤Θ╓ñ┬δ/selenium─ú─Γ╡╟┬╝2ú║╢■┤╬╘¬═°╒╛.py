from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#初始化driver
driver  = webdriver.Chrome('./chromedriver.exe')
driver.get('https://www.tianshie.com/wp-login.php')

#账号及密码
id = 'sme'
pw = 'litian221719'

#输入
elem = driver.find_element_by_name('log')
elem.clear()
elem.send_keys(id)

password = driver.find_element_by_name('pwd')
password.clear()
password.send_keys(pw)

elem.send_keys(Keys.RETURN)

#成功后输出源代码
print('源代码为：')
print(driver.page_source)