from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
url = 'https://passport.bilibili.com/login'

driver = webdriver.Chrome('./chromedriver.exe')
driver.get(url)

#要输入的内容
user = '15611531766'
pw = 'litian221719'

"""
需要注意特殊位置是name还是id
"""
elem = driver.find_element_by_id('login-username')
elem.clear()
elem.send_keys(user)

password = driver.find_element_by_id('login-passwd')
password.clear()
password.send_keys(pw)

elem.send_keys(Keys.RETURN)

input('手动完成验证码操作：')


time.sleep(10)
print('源代码如下：\n')
print(driver.page_source)
