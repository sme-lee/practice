import requests
login_url = 'http://exercise.kingname.info/exercise_login'
login_success = 'http://exercise.kingname.info/exercise_login_success'
data = {'username':'kingname',
        'password':'genius',
        'remember':'Yes'}

session = requests.Session()
#登录前访问登录后的网址会显示登录界面 ，表单登录只能使用session
before_login = session.get(login_success).text
print(before_login)

print('============开始登录=========')
#步骤为：1、登录，session返回登录的cookie    2、获取网页源代码并输出    表单数据从检查中获取
session.post(login_url, data = data).text
after_login = session.get(login_success).text
print(after_login)
