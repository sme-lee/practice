# 目的：发挥多核 cpu 优势

# # 了解计算机 cpu 和核心数量
# from multiprocessing import cpu_count
# print(cpu_count())
# 特点：动态创造少量进程

from multiprocessing import Process,Queue
import time
import requests
url = 'https://www.baidu.com/'
link_list = []
for i in range(10):
    link_list.append(url)


start = time.time()
class myProcess(Process):
    def __init__(self,q):
        Process.__init__(self)
        self.q = q
    def run(self):
        print('Starting',self.pid)          # pid 是什么
        while not self.q.empty():   # 表示什么
            crawler(self.q)
        print('Exiting',self.pid)
def crawler(q):
    url = q.get(timeout = 2)
    try:
        r = requests.get(url, timeout = 20)
        print(q.qsize(),r.status_code,url)
    except Exception as e:
        print(q.qsize(),url , "Error" , e)
if __name__ == '__main__':                          # 代表什么
    ProcessNames = [f'Process-{i}' for i in range(1,4)]
    workQueue = Queue(10)

    # 填充队列
    for url in link_list:
        workQueue.put(url)
    for i in range(0,3):
        p = myProcess(workQueue)
        p.daemon = True                             # 该处表示父进程结束后子进程自动终止
        p.start()
        p.join()
    end = time.time()
    print(f'Process + Queue 多进程爬虫的总时间为：',end-start)
    print('Main process Ended!')



