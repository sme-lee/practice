# 使用 Pool 发挥进程池功效

from multiprocessing import Pool,Manager        # Manager
import time
import requests

url1 = 'https://blog.csdn.net/weixin_30437481/article/details/101540482'
url2 = 'https://www.bing.com/translator/'
url3 =  'https://xw.qq.com/'
url4 = 'https://www.baidu.com/'
url5 = 'https://m.hao123.com/next/website'
url_list = []
for n in range(20):
    url_list.append(url1)
    url_list.append(url2)
    url_list.append(url3)
    url_list.append(url3)
    url_list.append(url5)
start = time.time()
def crawler (q , index):
    Process_id = 'Process-' + str(index)
    while not q.empty():
        url = q.get(timeout = 2)
        try:
            r = requests.get(url , timeout = 20)
            print(Process_id , q.qsize(), r.status_code , url)
        except Exception as e:
            print(Process_id , q.qsize() , url , 'Error:' , e)
if __name__ == '__main__':
    # 创建队列
    manager = Manager()
    workQueue = manager.Queue(100)

    # 填充队列
    for url in url_list:
        workQueue.put(url)
    pool = Pool (processes = 10)                                  # 进程数为10
    for i in range(10):
        pool.apply_async(crawler , args = (workQueue,i))         # 这里代表创建非阻塞进程
                                                                 # 阻塞进程：pool.apply()
    print(f'started processes')
    pool.close()
    pool.join()
    end = time.time()
    print('Pool + Queue 多进程爬虫的总时间为',end-start)
    print('Main process Ended!')

