# 一直保持五线程状态
# 使用 workQueue = Queue.Queue(1000) 建立了一个队列的对象，然后将对象传入 myThread 中
# thread = myThread(tName, workQueue)
# 用 for 循环和 put 方法来填充队列
# 用 url = q.get(timeout = 2) 获取链接

import threading
import requests
import time
import queue as Queue

# 链接列表
link_list = []

start = time.time()
class myThread(threading.Thread):
    def __init__(self , name , q):
        threading.Thread.__init__(self)
        self.name = name
        self.q = q
    def run(self):
        print('Starting' + self.name)
        while True:
            try:
                crawler (self.name,self.q)
            except:
                break
        print('Exiting'+self.name)
def crawler(threadName,q):
    url = q.get(timeout = 2)
    try :
        r = requests.get(url,timeout = 20)
        print(q.qsize(),threadName,r.status_code,url)       # q.qsize 返回队列的大小
    except Exception as e:
        print(q.qsize(),threadName,url,'Error:',e)
threadList = [f'Thread-{i}'for i in range(1,6)]
workQueue = Queue.Queue(1000)                   # 该方法表示
threads = []

# 创建新线程
for tName in threadList:
    thread = myThread(tName,workQueue)
    thread.start()
    threads.append(thread)

# 填充队列
for url in link_list:
    workQueue.put(url)      # put 方法表示

# 等待所有线程完成
for t in threads:
    t.join()
end = time.time()
print('Queue多线程爬虫的总时间为：',end - start)
print('Exiting Main Thread')
