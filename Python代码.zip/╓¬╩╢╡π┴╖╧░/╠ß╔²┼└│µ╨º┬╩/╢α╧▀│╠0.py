from multiprocessing.dummy import Pool
import time


def calc_power2(num):
    return(num **2)
pool = Pool(1)

#多进程运算
start = time.time()
orgin_num = list(range(1000))
result = pool.map(calc_power2,orgin_num)
print(f'计算0-9的平方分别为：{result}')
end = time.time()
print(f'花费的时间为：{end-start}')