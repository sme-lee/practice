import time
import requests
from multiprocessing import Manager,Pool

# 改进：删除进程名，仅保留队列
# 得出结论：10 进程几乎为最快进程数

# 准备好网址列表
url1 = 'https://blog.csdn.net/weixin_30437481/article/details/101540482'
url2 = 'https://www.bing.com/translator/'
url3 = 'https://xw.qq.com/'
url4 = 'https://www.baidu.com/'
url5 = 'https://m.hao123.com/next/website'
url_list = []
for n in range(20):
    url_list.append(url1)
    url_list.append(url2)
    url_list.append(url3)
    url_list.append(url4)
    url_list.append(url5)

# 定义抓取函数
def crawler(name , workqueue):
    while not workqueue.empty():
        url = workqueue.get()
        code = requests.get(url).status_code
        print(code, workqueue.qsize(), url)

if __name__ == '__main__':
    # 开始创建队列及进程池
    p_num_list = list(range(6,11))
    time_list = []
    for p_num in p_num_list:
        start = time.time()

        manager = Manager()
        workqueue = manager.Queue(100)
        for url in url_list:
            workqueue.put(url)

        pool = Pool(p_num)
        names = [f'进程{i}'for i in range(1,p_num+1)]
        for name in names:
            pool.apply_async(crawler, (name,workqueue))
        pool.close()
        pool.join()

        end = time.time()
        print(end - start)
        time_list.append(end-start)
    small_time = min(time_list)
    for i in range(5):
        print(f'{i+1}进程花费的时间为{time_list[i]}.')
    print(f'花费的时间最短的进程为{time_list.index(small_time)+1},时间最短为{small_time}')