import time
import requests
# 35 线程最快

url1 = 'https://blog.csdn.net/weixin_30437481/article/details/101540482'
url2 = 'https://www.bing.com/translator/'
url3 =  'https://xw.qq.com/'
url4 = 'https://www.baidu.com/'
url5 = 'https://m.hao123.com/next/website'
url_list = []
for n in range(20):
    url_list.append(url1)
    url_list.append(url2)
    url_list.append(url3)
    url_list.append(url3)
    url_list.append(url5)

import threading
import queue as Queue
class myThread(threading.Thread):
    def __init__(self,q):
        threading.Thread.__init__(self)
        self.q = q
    def run(self):
        while not self.q.empty():
            url = self.q.get()
            code = requests.get(url).status_code
            print(code,self.q.qsize(),url)
# 建立队列和线程列表



time_list = []
min_num = 40
for i in range(min_num,min_num+11):   # 代表线程数
    ts = []
    start = time.time()
    workqueue = Queue.Queue(100)
    for url in url_list:
        workqueue.put(url)
    for j in range(1,i+1):
        t = myThread(workqueue)
        t.start()
        ts.append(t)
    for t in ts:
        t.join()
    end = time.time()

    time_list.append(end - start)
for i in range(len(time_list)):
    print(f'{i+min_num}线程花费的时间为：',time_list[i])
print(f'速度最快的线程数是{time_list.index(min(time_list))+min_num}线程，最短时间为{min(time_list)}秒。')