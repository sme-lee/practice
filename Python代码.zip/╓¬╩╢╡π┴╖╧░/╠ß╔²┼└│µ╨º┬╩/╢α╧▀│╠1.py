import requests
import time
import matplotlib.pyplot as plt
from multiprocessing.dummy import Pool

def surf(i):
    url = 'http://www.baidu.com'
    source = requests.get(url).content.decode()
def time_list(n_list):
    time_list = []
    for n in n_list:
        start = time.time()
        pool = Pool(n)
        pool.map(surf,list(range(20)))
        end = time.time()
        print(f'{n}线程访问百度首页一百次所需要的时间为：{end-start}秒.')
        time_list.append(end-start)
    return(time_list)
#制作图像
def draw(n_list,time_list):
    plt.plot(n_list,time_list,linewidth = 1)
    plt.title('time',fontsize = 25)

    plt.xlabel('the number of multiprocessing',fontsize = 16)
    plt.ylabel('time needed',fontsize = 16)
    plt.tick_params(axis = 'both',labelsize = 16)
    plt.show()

n_list = list(range(1,21))
time_list_1=time_list(n_list)

draw(n_list,time_list_1)
min = time_list_1[0]
for i in range(len(time_list_1)):
    if min > time_list_1[i] :
        min = time_list_1[i]

print(f'最少的时间为{min}秒\n最快的是{i}线程.')

